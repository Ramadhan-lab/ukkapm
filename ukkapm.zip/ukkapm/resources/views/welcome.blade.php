@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Selamat Datang</div>

                <div class="card-body">
                  <h3>Selamat Datang Di Aplikasi Pegaduan Masyarakat.</h3>
                  <p>Silakan Login Atau Mendaftar pada tombol di bawah ini</p>
                  <div class="row">
                     <div class="col-6">
                       <a href="{{ route('login') }}" class="btn btn-primary btn-block btn-lg">LOGIN</a>
                  </div>
                     <div class="col-6">
                       <a href="{{ route('register') }}" class="btn btn-danger btn-block btn-lg">DAFTAR</a>
                     </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
