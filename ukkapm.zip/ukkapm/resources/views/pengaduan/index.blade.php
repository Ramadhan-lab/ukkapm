@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card shadow-lg">
                <div class="card-header bg-secondary text-white">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if($errors->any())
                    <div class="alert alert-danger" role="alert">
                         <ul>
                             @foreach($errors->all() as $error)
                             <li>{{ $error }}</li>
                             @endforeach
                         </ul>
                    </div>
                    @endif
                    <p>SELAMAT DATANG!! Daftar Pengaduan Anda</p>
                    <!-- Button to Open the Modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
  Tambah Laporan Pengaduan Masyarakat
</button>

<!-- The Modal -->
<form action="{{ route('pengaduan.simpan') }}" method="POST" enctype="multipart/form-data">
     @csrf
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Tambah Pengaduan</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <div class="form-group">
            <label>Laporan</label>
            <textarea placeholder="Isikan Laporan Anda" class="form-control" name="laporan"></textarea>
        </div>
        <div class="form-group">
            <label>Foto</label>
            <input type="file" class="form-control" name="foto">
        </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger">Simpan</button>
      </div>

    </div>
  </div>
</div>
</form>
                    <table class="table table-bordered table-hover">
                        <tr>
                            <th>NO</th>
                            <th>Tanggal Lapor</th>
                            <th>Isi Pengaduan</th>
                            <th>Status</th>
                            <th>Lihat Detail</th>
                        </tr>
                        @foreach($data as $d)
                        <tr>
                            <td>NO</td>
                            <td>Tanggal Lapor</td>
                            <td>Isi Pengaduan</td>
                            <td>Status</td>
                            <td>Lihat Detail</td>
                        </tr>
                        @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
