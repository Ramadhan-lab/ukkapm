<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pengaduan;
use Illuminate\Support\Facades\Auth;

class PengaduanController extends Controller
{
    public function index()
    {
        $data = Pengaduan::where('user_id', Auth::id())->get();
        return view('pengaduan.index')->with([
            'data' => $data
        ]);
    }
    public function simpan(Request $request)
    {
        $this->validate($request, [
            'laporan' => 'required',
            'foto' => 'mimes:png,jpg'
        ],[
            'laporan.required' => 'Laporannya Harus Diisi'
        ]);
        $namafoto = time().".".$request->foto->extension();
        $request->foto->move(public_path('foto'), $namafoto);

        return redirect()->back();
    }
}
