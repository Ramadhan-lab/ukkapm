<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;


class PenggunaController extends Controller
{
    public function index()
    {
        $dataA = User::whereRoleIs('admin')->get();
        $dataP = User::whereRoleIs('petugas')->get();
        $dataM = User::whereRoleIs('masyarakat')->get();

        return view('pengguna.index')->with([
            'dataA' => $dataA,
            'dataP' => $dataP,
            'dataM' => $dataM,

        ]);
    }
    public function tambah(Request $request)
    {
        User::create([
            'name' => $request['name'],
            'email' => $request['email'],
            'password' => Hash::make($request['password']),
            'nik' => $request['nik'],
            'tlp' => $request['tlp'],
        ])->attachRole($request['peran']);
        return redirect()->route('pengguna.index');
    }
    public function hapus($id)
    {
        $hapus = User::findOrFail($id);
        $hapus->delete();
        return redirect()->route('pengguna.index');
    }
    public function edit($id)
    {
        $data = User::findOrFail($id);
        return view('pengguna.edit')->with([
            'data' =>$data
        ]);
    }
    public function prosesedit(Request $request, $id)
    {
        $edit = User::findOrFail($id);
        $edit->name = $request['name'];
        $edit->email = $request['email'];
        if($request['password']){
            $edit->password = $request['password'];
        }
        $edit->nik = $request['nik'];
        $edit->tlp = $request['tlp'];
        $edit->save();
        $edit->syncRoles([$request['peran']]);
        return redirect()->route('pengguna.index');

    }
}
