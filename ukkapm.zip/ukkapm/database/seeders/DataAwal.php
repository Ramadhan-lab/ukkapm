<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Role;
use App\Models\User;

class DataAwal extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //peran (admin, petugas, masyarakat)
        $peran = new Role();
        $peran->name = 'admin';
        $peran->save();

        $peran = new Role();
        $peran->name = 'petugas';
        $peran->save();

        $peran = new Role();
        $peran->name = 'masyarakat';
        $peran->save();

        $admin = new User();
        $admin->email = 'admin@apm.com';
        $admin->password = bcrypt('1234567890');
        $admin->name = 'Admin Utama';
        $admin->tlp = '0987654321';
        $admin->nik = '7277397649651434';
        $admin->save();
        $admin->attachRole('admin');

        $petugas = new User();
        $petugas->email = 'petugas@apm.com';
        $petugas->password = bcrypt('1234567890');
        $petugas->name = 'Petugas Utama';
        $petugas->tlp = '058568565';
        $petugas->nik = '5238469925551';
        $petugas->save();
        $petugas->attachRole('petugas');

    }
}
