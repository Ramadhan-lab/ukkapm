<?php

use App\Http\Controllers\PengaduanController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PenggunaController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/pengguna', [PenggunaController::class, 'index'])->middleware(['auth', 'role:admin'])->name('pengguna.index');
Route::post('/pengguna', [PenggunaController::class, 'tambah'])->middleware(['auth', 'role:admin'])->name('pengguna.tambah');
Route::get('/pengguna/hapus/{id}', [PenggunaController::class, 'hapus'])->middleware(['auth', 'role:admin'])->name('pengguna.hapus');
Route::get('/pengguna/edit/{id}', [PenggunaController::class, 'edit'])->middleware(['auth', 'role:admin'])->name('pengguna.edit');
Route::post('/pengguna/edit/{id}', [PenggunaController::class, 'prosesedit'])->middleware(['auth', 'role:admin'])->name('pengguna.prosesedit');
Route::get('/pengaduan', [PengaduanController::class, 'index'])->middleware(['auth', 'role:masyarakat'])->name('pengaduan.index');
Route::post('/pengaduan', [PengaduanController::class, 'simpan'])->middleware(['auth', 'role:masyarakat'])->name('pengaduan.simpan');



