<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Selamat Datang</div>

                <div class="card-body">
                  <h3>Selamat Datang Di Aplikasi Pegaduan Masyarakat.</h3>
                  <p>Silakan Login Atau Mendaftar pada tombol di bawah ini</p>
                  <div class="row">
                     <div class="col-6">
                       <a href="<?php echo e(route('login')); ?>" class="btn btn-primary btn-block btn-lg">LOGIN</a>
                  </div>
                     <div class="col-6">
                       <a href="<?php echo e(route('register')); ?>" class="btn btn-danger btn-block btn-lg">DAFTAR</a>
                     </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ukkapm\resources\views/welcome.blade.php ENDPATH**/ ?>